<?php
$senha = "admin"; // senha que você quer para o admin
$hash = password_hash($senha, PASSWORD_DEFAULT);
echo $hash;
?>
