document.addEventListener("DOMContentLoaded", () => {
    const btnMenu = document.getElementById("btnMenu");
    const sidebar = document.getElementById("sidebar");
    const content = document.querySelector(".content");

    // Restaurar estado salvo
    const menuEstado = localStorage.getItem("menuSidebar");

    if (menuEstado === "fechado") {
        sidebar.classList.add("hide");
        content.classList.add("expand");
    }

    // Clique no botão
    btnMenu.onclick = () => {
        sidebar.classList.toggle("hide");
        content.classList.toggle("expand");

        // Salvar estado
        if (sidebar.classList.contains("hide")) {
            localStorage.setItem("menuSidebar", "fechado");
        } else {
            localStorage.setItem("menuSidebar", "aberto");
        }
    };
});
