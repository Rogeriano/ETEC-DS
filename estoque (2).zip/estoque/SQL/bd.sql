CREATE DATABASE estoque
CHARACTER SET utf8mb4
COLLATE utf8mb4_0900_ai_ci;

USE estoque;
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE fornecedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    cnpj VARCHAR(20),
    telefone VARCHAR(30),
    email VARCHAR(120),
    endereco VARCHAR(255)
);
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    cargo VARCHAR(50),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(200) NOT NULL,
    categoria_id INT,
    sku VARCHAR(50) UNIQUE,
    codigo_barra VARCHAR(50),
    preco_custo DECIMAL(10,2),
    preco_venda DECIMAL(10,2),
    ativo TINYINT(1) DEFAULT 1,
    fornecedor_id INT,

    CONSTRAINT fk_produto_categoria
        FOREIGN KEY (categoria_id) REFERENCES categorias(id),

    CONSTRAINT fk_produto_fornecedor
        FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id)
);
CREATE TABLE estoque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    quantidade INT DEFAULT 0,
    lote VARCHAR(50) NOT NULL,
    validade DATE,
    localizacao_atual VARCHAR(255),
    data_recebimento DATETIME DEFAULT CURRENT_TIMESTAMP,
    embalagem VARCHAR(100), -- Palete | Caixa | Gaiola | Pacote

    CONSTRAINT fk_estoque_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
CREATE TABLE historico_entrada (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    lote VARCHAR(50) NOT NULL,
    validade DATE,
    fornecedor_id INT,
    usuario_id INT,
    nota_fiscal_path VARCHAR(255),
    embalagem VARCHAR(100),
    data_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_hist_entrada_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id),

    CONSTRAINT fk_hist_entrada_fornecedor
        FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id),

    CONSTRAINT fk_hist_entrada_usuario
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
CREATE TABLE expedicao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    lote VARCHAR(50),
    validade DATE,
    rua VARCHAR(10),
    prateleira VARCHAR(10),
    nivel VARCHAR(10),
    cliente VARCHAR(255) NOT NULL,
    endereco_cliente VARCHAR(255),
    status ENUM('pendente','concluida') DEFAULT 'pendente',
    data_solicitacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_saida DATETIME,

    CONSTRAINT fk_expedicao_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
CREATE TABLE historico_movimentacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    tipo ENUM('entrada','saida') NOT NULL,
    quantidade INT NOT NULL,
    lote VARCHAR(50),
    validade DATE,
    usuario VARCHAR(100),
    localizacao VARCHAR(50),
    cliente VARCHAR(255),
    endereco_cliente VARCHAR(255),
    data_movimentacao DATETIME DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_hist_mov_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
CREATE TABLE estoque_movimentacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    tipo ENUM('entrada','saida') NOT NULL,
    quantidade INT NOT NULL,
    usuario_id INT,
    motivo VARCHAR(255),
    data_movimentacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mov_produto
        FOREIGN KEY (produto_id) REFERENCES produtos(id),

    CONSTRAINT fk_mov_usuario
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
