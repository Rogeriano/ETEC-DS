<?php
require '../php/conexao.php';
$armazenagem = $pdo->query("
SELECT e.id, p.nome, e.lote, e.quantidade, e.validade
FROM estoque e
JOIN produtos p ON e.produto_id=p.id
WHERE e.quantidade > 0
ORDER BY p.nome ASC
")->fetchAll();
?>
<h1>Relatório de Armazenagem</h1>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Produto</th><th>Lote</th><th>Quantidade</th><th>Validade</th></tr>
<?php foreach($armazenagem as $a): ?>
<tr>
<td><?= $a['id'] ?></td>
<td><?= htmlspecialchars($a['nome']) ?></td>
<td><?= htmlspecialchars($a['lote']) ?></td>
<td><?= $a['quantidade'] ?></td>
<td><?= $a['validade'] ?></td>
</tr>
<?php endforeach; ?>
</table>
