<?php
require '../php/conexao.php';
$valores = $pdo->query("
SELECT p.nome, e.quantidade, p.preco_custo, (e.quantidade * p.preco_custo) AS total
FROM estoque e
JOIN produtos p ON e.produto_id=p.id
ORDER BY p.nome ASC
")->fetchAll();

$totalGeral = 0;
foreach($valores as $v) { $totalGeral += $v['total']; }
?>
<h1>Valor Total do Estoque</h1>
<table border="1" cellpadding="5">
<tr><th>Produto</th><th>Quantidade</th><th>Preço Custo</th><th>Total</th></tr>
<?php foreach($valores as $v): ?>
<tr>
<td><?= htmlspecialchars($v['nome']) ?></td>
<td><?= $v['quantidade'] ?></td>
<td>R$ <?= number_format($v['preco_custo'],2,',','.') ?></td>
<td>R$ <?= number_format($v['total'],2,',','.') ?></td>
</tr>
<?php endforeach; ?>
<tr>
<td colspan="3"><b>Total Geral</b></td>
<td><b>R$ <?= number_format($totalGeral,2,',','.') ?></b></td>
</tr>
</table>
