<?php
require '../php/conexao.php';
$estoque = $pdo->query("
SELECT e.id, p.nome, e.lote, e.quantidade, e.validade
FROM estoque e
JOIN produtos p ON e.produto_id=p.id
WHERE e.quantidade <= 5
ORDER BY e.quantidade ASC
")->fetchAll();
?>
<h1>Relatório de Estoque Baixo</h1>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Produto</th><th>Lote</th><th>Quantidade</th><th>Validade</th></tr>
<?php foreach($estoque as $e): ?>
<tr>
<td><?= $e['id'] ?></td>
<td><?= htmlspecialchars($e['nome']) ?></td>
<td><?= htmlspecialchars($e['lote']) ?></td>
<td><?= $e['quantidade'] ?></td>
<td><?= $e['validade'] ?></td>
</tr>
<?php endforeach; ?>
</table>
