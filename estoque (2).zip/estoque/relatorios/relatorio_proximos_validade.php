<?php
require '../php/conexao.php';
$validade = $pdo->query("
SELECT e.id, p.nome, e.lote, e.quantidade, e.validade
FROM estoque e
JOIN produtos p ON e.produto_id=p.id
WHERE e.validade IS NOT NULL AND e.validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY e.validade ASC
")->fetchAll();
?>
<h1>Produtos Próximos da Validade (até 30 dias)</h1>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Produto</th><th>Lote</th><th>Quantidade</th><th>Validade</th></tr>
<?php foreach($validade as $v): ?>
<tr>
<td><?= $v['id'] ?></td>
<td><?= htmlspecialchars($v['nome']) ?></td>
<td><?= htmlspecialchars($v['lote']) ?></td>
<td><?= $v['quantidade'] ?></td>
<td><?= $v['validade'] ?></td>
</tr>
<?php endforeach; ?>
</table>
