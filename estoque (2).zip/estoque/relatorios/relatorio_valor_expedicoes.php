<?php
require '../php/conexao.php';
$valoresExp = $pdo->query("
SELECT p.nome, e.quantidade, p.preco_venda, (e.quantidade * p.preco_venda) AS total
FROM expedicao e
JOIN produtos p ON e.produto_id=p.id
WHERE e.status='concluida'
ORDER BY e.data_saida DESC
")->fetchAll();

$totalGeral = 0;
foreach($valoresExp as $v) { $totalGeral += $v['total']; }
?>
<h1>Valor Total de Expedições Concluídas</h1>
<table border="1" cellpadding="5">
<tr><th>Produto</th><th>Quantidade</th><th>Preço Venda</th><th>Total</th></tr>
<?php foreach($valoresExp as $v): ?>
<tr>
<td><?= htmlspecialchars($v['nome']) ?></td>
<td><?= $v['quantidade'] ?></td>
<td>R$ <?= number_format($v['preco_venda'],2,',','.') ?></td>
<td>R$ <?= number_format($v['total'],2,',','.') ?></td>
</tr>
<?php endforeach; ?>
<tr>
<td colspan="3"><b>Total Geral</b></td>
<td><b>R$ <?= number_format($totalGeral,2,',','.') ?></b></td>
</tr>
</table>
