<?php
require '../php/conexao.php';
$produtos = $pdo->query("SELECT p.id, p.nome, p.codigo_barra, c.nome AS categoria, p.preco_custo, p.preco_venda
                         FROM produtos p
                         LEFT JOIN categorias c ON p.categoria_id=c.id
                         ORDER BY p.nome ASC")->fetchAll();
?>
<h1>Relatório de Produtos</h1>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Nome</th><th>Código de Barras</th><th>Categoria</th><th>Preço Custo</th><th>Preço Venda</th></tr>
<?php foreach($produtos as $p): ?>
<tr>
<td><?= $p['id'] ?></td>
<td><?= htmlspecialchars($p['nome']) ?></td>
<td><?= htmlspecialchars($p['codigo_barra']) ?></td>
<td><?= htmlspecialchars($p['categoria']) ?></td>
<td>R$ <?= number_format($p['preco_custo'],2,',','.') ?></td>
<td>R$ <?= number_format($p['preco_venda'],2,',','.') ?></td>
</tr>
<?php endforeach; ?>
</table>
