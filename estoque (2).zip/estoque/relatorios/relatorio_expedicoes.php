<?php
require '../php/conexao.php';
$expedicoes = $pdo->query("
SELECT e.id, p.nome AS produto, e.quantidade, e.lote, e.cliente, e.endereco_cliente, e.status, e.data_solicitacao, e.data_saida
FROM expedicao e
JOIN produtos p ON e.produto_id=p.id
ORDER BY e.data_solicitacao DESC
")->fetchAll();
?>
<h1>Relatório de Expedições</h1>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Produto</th><th>Quantidade</th><th>Lote</th><th>Cliente</th><th>Endereço</th><th>Status</th><th>Data Solicitação</th><th>Data Saída</th></tr>
<?php foreach($expedicoes as $e): ?>
<tr>
<td><?= $e['id'] ?></td>
<td><?= htmlspecialchars($e['produto']) ?></td>
<td><?= $e['quantidade'] ?></td>
<td><?= htmlspecialchars($e['lote']) ?></td>
<td><?= htmlspecialchars($e['cliente']) ?></td>
<td><?= htmlspecialchars($e['endereco_cliente']) ?></td>
<td><?= $e['status'] ?></td>
<td><?= $e['data_solicitacao'] ?></td>
<td><?= $e['data_saida'] ?></td>
</tr>
<?php endforeach; ?>
</table>
