<?php
require 'conexao.php'; // Inclua seu arquivo de conexão PDO

$erro = '';
$sucesso = '';

// =====================
// Atualizar localização e embalagem
// ===================== 
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['transferir'])) {
    $estoque_id = intval($_POST['estoque_id']);
    $rua = trim($_POST['rua']);
    $prateleira = trim($_POST['prateleira']);
    $nivel = trim($_POST['nivel']);
    $embalagem_array = $_POST['embalagem'] ?? [];
    $embalagem = implode(', ', $embalagem_array);
    $nova_localizacao = "$rua - Prateleira $prateleira - Nível $nivel";

    if ($estoque_id > 0 && $rua && $prateleira && $nivel && $embalagem) {
        $stmt = $pdo->prepare("
            UPDATE estoque 
            SET localizacao_atual = :nova_localizacao, embalagem = :embalagem 
            WHERE id = :id
        ");
        $stmt->execute([
            'nova_localizacao' => $nova_localizacao,
            'embalagem' => $embalagem,
            'id' => $estoque_id
        ]);

        $sucesso = "Localização e embalagem atualizadas com sucesso!";
    } else {
        $erro = "Informe todos os campos e selecione ao menos uma embalagem.";
    }
}

// =====================
// Buscar estoque
// =====================
$stmt = $pdo->query("
    SELECT 
        e.id AS estoque_id,
        p.nome,
        p.codigo_barra,
        e.quantidade,
        e.lote,
        e.localizacao_atual,
        e.embalagem
    FROM estoque e
    INNER JOIN produtos p ON e.produto_id = p.id
    ORDER BY e.localizacao_atual IS NULL DESC, p.nome, e.lote
");
$estoque = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Estoque Atual</title>
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px; text-align: left; border: 1px solid #ccc; }
    .pendente { color: red; font-weight: bold; }
    .localizado { color: green; }
    button { padding: 4px 8px; cursor: pointer; }

    /* Estilo do Modal */
    .modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0; top: 0;
        width: 100%; height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 20px;
        width: 350px;
        border-radius: 8px;
        text-align: center;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 24px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover { color: #000; }
    input[type="text"] { width: 80px; margin-bottom: 10px; }
</style>
</head>
<body>

<h1>Estoque Atual</h1>

<?php if ($erro) echo "<p style='color:red;'>$erro</p>"; ?>
<?php if ($sucesso) echo "<p style='color:green;'>$sucesso</p>"; ?>

<table>
    <tr>
        <th>Produto</th>
        <th>Código de Barras</th>
        <th>Quantidade</th>
        <th>Lote</th>
        <th>Localização</th>
        <th>Embalagem</th>
        <th>Ações</th>
    </tr>
    <?php foreach($estoque as $e): ?>
    <tr>
        <td><?= htmlspecialchars($e['nome']) ?></td>
        <td><?= htmlspecialchars($e['codigo_barra']) ?></td>
        <td><?= $e['quantidade'] ?></td>
        <td><?= htmlspecialchars($e['lote']) ?></td>
        <td>
            <?= $e['localizacao_atual'] ? "<span class='localizado'>{$e['localizacao_atual']}</span>" : "<span class='pendente'>Pendente</span>" ?>
        </td>
        <td><?= htmlspecialchars($e['embalagem'] ?? '-') ?></td>
        <td>
            <button onclick="abrirModal(<?= $e['estoque_id'] ?>, '<?= $e['localizacao_atual'] ?>', '<?= $e['embalagem'] ?? '' ?>')">
                <?= $e['localizacao_atual'] ? 'Alterar' : 'Armazenar' ?>
            </button>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- Modal -->
<div id="modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal()">&times;</span>
        <h3>Atribuir Localização e Embalagem</h3>
        <form method="POST" id="formModal">
            <input type="hidden" name="estoque_id" id="estoque_id">
            <input type="text" name="rua" id="rua" placeholder="Rua" required>
            <input type="text" name="prateleira" id="prateleira" placeholder="Prateleira" required>
            <input type="text" name="nivel" id="nivel" placeholder="Nível" required>
            <br><br>
            <label>Embalagem*</label><br>
            <input type="checkbox" name="embalagem[]" value="Pallet" id="Pallet"> <label for="Pallet">Pallet</label>
            <input type="checkbox" name="embalagem[]" value="Caixa" id="Caixa"> <label for="Caixa">Caixa</label>
            <input type="checkbox" name="embalagem[]" value="Gaiola" id="Gaiola"> <label for="Gaiola">Gaiola</label>
            <input type="checkbox" name="embalagem[]" value="Pacote" id="Pacote"> <label for="Pacote">Pacote</label>
            <br><br>
            <button type="submit" name="transferir">Salvar</button>
        </form>
    </div>
</div>

<script>
function abrirModal(id, localizacao, embalagem) {
    document.getElementById('modal').style.display = 'block';
    document.getElementById('estoque_id').value = id;

    if(localizacao) {
        const rua = localizacao.split(' - ')[0];
        const prateleira = localizacao.match(/Prateleira (\d+)/);
        const nivel = localizacao.match(/Nível (\d+)/);

        document.getElementById('rua').value = rua || '';
        document.getElementById('prateleira').value = prateleira ? prateleira[1] : '';
        document.getElementById('nivel').value = nivel ? nivel[1] : '';
    } else {
        document.getElementById('rua').value = '';
        document.getElementById('prateleira').value = '';
        document.getElementById('nivel').value = '';
    }

    // Limpar checkboxes
    ['Pallet','Caixa','Gaiola','Pacote'].forEach(function(e){
        document.getElementById(e).checked = false;
    });

    // Marcar embalagens existentes
    if(embalagem) {
        embalagem.split(', ').forEach(function(val){
            if(document.getElementById(val)) document.getElementById(val).checked = true;
        });
    }
}

function fecharModal() {
    document.getElementById('modal').style.display = 'none';
}

// Fechar modal ao clicar fora do conteúdo
window.onclick = function(event) {
    if (event.target == document.getElementById('modal')) {
        fecharModal();
    }
}
</script>

</body>
</html>
