<?php

require 'conexao.php';

// =====================
// Variáveis
// =====================
$erro = '';
$sucesso = '';
$usuario_id = $_SESSION['usuario_id'] ?? 1; // Ajuste conforme login do sistema

// =====================
// Buscar produtos e fornecedores
// =====================
$produtos = $pdo->query("SELECT * FROM produtos ORDER BY nome ASC")->fetchAll();
$fornecedores = $pdo->query("SELECT * FROM fornecedores ORDER BY nome ASC")->fetchAll();

// =====================
// Processar recebimento
// =====================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = intval($_POST['produto_id']);
    $quantidade = intval($_POST['quantidade']);
    $lote = trim($_POST['lote']);
    $validade = $_POST['validade'] ?: null;
    $fornecedor_id = intval($_POST['fornecedor_id'] ?? 0);

    // Tipo de embalagem: radio ou checkbox
    $embalagem_array = $_POST['embalagem'] ?? [];
    if (empty($embalagem_array)) {
        $erro = "Selecione pelo menos um tipo de embalagem!";
    } else {
        $embalagem = implode(', ', $embalagem_array);
    }

    // Upload da nota fiscal
    $nota_fiscal_path = null;
    if (isset($_FILES['nota_fiscal']) && $_FILES['nota_fiscal']['error'] == 0) {
        $ext = pathinfo($_FILES['nota_fiscal']['name'], PATHINFO_EXTENSION);
        $nota_fiscal_path = 'uploads/notas/' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['nota_fiscal']['tmp_name'], $nota_fiscal_path);
    }

    if (!$erro && ($produto_id == 0 || $quantidade <= 0 || empty($lote))) {
        $erro = "Produto, quantidade e lote são obrigatórios!";
    }

    if (!$erro) {
        // Verificar se já existe estoque do mesmo produto+lote
        $stmt_check = $pdo->prepare("SELECT id, quantidade FROM estoque WHERE produto_id=:produto_id AND lote=:lote");
        $stmt_check->execute(['produto_id'=>$produto_id, 'lote'=>$lote]);
        $estoque_existente = $stmt_check->fetch();

        if ($estoque_existente) {
            // Atualizar quantidade e embalagem
            $stmt = $pdo->prepare("
                UPDATE estoque 
                SET quantidade = quantidade + :quantidade,
                    embalagem = :embalagem,
                    validade = :validade,
                    data_recebimento = NOW()
                WHERE id = :id
            ");
            $stmt->execute([
                'quantidade'=>$quantidade,
                'embalagem'=>$embalagem,
                'validade'=>$validade,
                'id'=>$estoque_existente['id']
            ]);
        } else {
            // Inserir novo estoque
            $stmt = $pdo->prepare("
                INSERT INTO estoque 
                (produto_id, quantidade, lote, validade, embalagem, data_recebimento)
                VALUES 
                (:produto_id, :quantidade, :lote, :validade, :embalagem, NOW())
            ");
            $stmt->execute([
                'produto_id'=>$produto_id,
                'quantidade'=>$quantidade,
                'lote'=>$lote,
                'validade'=>$validade,
                'embalagem'=>$embalagem
            ]);
        }

        // Inserir histórico de entrada
        $stmt_hist = $pdo->prepare("
            INSERT INTO historico_entrada 
            (produto_id, quantidade, lote, validade, fornecedor_id, usuario_id, nota_fiscal_path, embalagem, data_entrada)
            VALUES 
            (:produto_id, :quantidade, :lote, :validade, :fornecedor_id, :usuario_id, :nota_fiscal_path, :embalagem, NOW())
        ");
        $stmt_hist->execute([
            'produto_id'=>$produto_id,
            'quantidade'=>$quantidade,
            'lote'=>$lote,
            'validade'=>$validade,
            'fornecedor_id'=>$fornecedor_id ?: null,
            'usuario_id'=>$usuario_id,
            'nota_fiscal_path'=>$nota_fiscal_path,
            'embalagem'=>$embalagem
        ]);

        $sucesso = "Mercadoria recebida com sucesso!";
    }
}

// =====================
// Buscar histórico (últimas 10 entradas)
// =====================
$historico = $pdo->query("
    SELECT h.*, p.nome AS produto_nome, f.nome AS fornecedor_nome, u.nome AS usuario_nome
    FROM historico_entrada h
    LEFT JOIN produtos p ON h.produto_id = p.id
    LEFT JOIN fornecedores f ON h.fornecedor_id = f.id
    LEFT JOIN usuarios u ON h.usuario_id = u.id
    ORDER BY h.data_entrada DESC
    LIMIT 10
")->fetchAll();
?>

<h1>Recebimento de Mercadorias</h1>

<?php if ($erro) echo "<p style='color:red;'>$erro</p>"; ?>
<?php if ($sucesso) echo "<p style='color:green;'>$sucesso</p>"; ?>

<form method="POST" enctype="multipart/form-data" style="margin-bottom:20px;">
    <label>Produto*</label><br>
    <select name="produto_id" required>
        <option value="">Selecione o produto</option>
        <?php foreach($produtos as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome']) ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Lote*</label><br>
    <input type="text" name="lote" placeholder="Lote" required><br><br>

    <label>Quantidade Total*</label><br>
    <input type="number" name="quantidade" placeholder="Quantidade" required><br><br>

    <label>Tipo de Embalagem*</label><br>
    <input type="checkbox" name="embalagem[]" value="Pallet"> Pallet
    <input type="checkbox" name="embalagem[]" value="Caixa"> Caixa
    <input type="checkbox" name="embalagem[]" value="Gaiola"> Gaiola
    <input type="checkbox" name="embalagem[]" value="Pacote"> Pacote
    <br><br>

    <label>Validade</label><br>
    <input type="date" name="validade"><br><br>

    <label>Fornecedor</label><br>
    <select name="fornecedor_id">
        <option value="">Selecione o fornecedor</option>
        <?php foreach($fornecedores as $f): ?>
            <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['nome']) ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Nota Fiscal</label><br>
    <input type="file" name="nota_fiscal" accept=".pdf,.jpg,.png"><br><br>

    <button type="submit">Registrar Recebimento</button>
</form>

<h2>Últimas Entradas</h2>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Produto</th>
        <th>Lote</th>
        <th>Quantidade Total</th>
        <th>Embalagem</th>
        <th>Validade</th>
        <th>Fornecedor</th>
        <th>Usuário</th>
        <th>Nota Fiscal</th>
        <th>Data</th>
    </tr>
    <?php foreach($historico as $h): ?>
    <tr>
        <td><?= htmlspecialchars($h['produto_nome']) ?></td>
        <td><?= htmlspecialchars($h['lote']) ?></td>
        <td><?= $h['quantidade'] ?></td>
        <td><?= htmlspecialchars($h['embalagem']) ?></td>
        <td><?= $h['validade'] ?></td>
        <td><?= htmlspecialchars($h['fornecedor_nome'] ?? '-') ?></td>
        <td><?= htmlspecialchars($h['usuario_nome'] ?? '-') ?></td>
        <td>
            <?php if($h['nota_fiscal_path']): ?>
                <a href="<?= $h['nota_fiscal_path'] ?>" target="_blank">Ver</a>
            <?php else: ?>
                -
            <?php endif; ?>
        </td>
        <td><?= $h['data_entrada'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
