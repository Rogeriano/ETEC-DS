<?php
require __DIR__ . '/conexao.php';

// ======================
// INDICADORES DO DASHBOARD
// ======================

// Total de produtos cadastrados
$stmt = $pdo->query("SELECT COUNT(*) FROM produtos");
$totalProdutos = $stmt->fetchColumn() ?? 0;

// Total de posições com estoque disponível
$stmt = $pdo->query("SELECT COUNT(*) FROM estoque WHERE quantidade > 0");
$totalArmazenagem = $stmt->fetchColumn() ?? 0;

// Produtos próximos da validade (30 dias)
$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM estoque
    WHERE validade IS NOT NULL
      AND validade <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
");
$proximosValidade = $stmt->fetchColumn() ?? 0;

// Estoque baixo
$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM estoque 
    WHERE quantidade <= 5
");
$estoqueBaixo = $stmt->fetchColumn() ?? 0;

// Total de expedições (saídas)
$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM estoque_movimentacoes
    WHERE tipo = 'saida'
");
$totalExpedicao = $stmt->fetchColumn() ?? 0;

// Valor total em estoque
$stmt = $pdo->query("
    SELECT SUM(e.quantidade * p.preco_custo)
    FROM estoque e
    JOIN produtos p ON p.id = e.produto_id
");
$totalValorEstoque = $stmt->fetchColumn() ?? 0;

// Valor total expedido
$stmt = $pdo->query("
    SELECT SUM(ex.quantidade * p.preco_venda)
    FROM expedicao ex
    JOIN produtos p ON p.id = ex.produto_id
    WHERE ex.status = 'concluida'
");
$totalValorExpedicao = $stmt->fetchColumn() ?? 0;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Dashboard - Centro de Distribuição</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 30px;
}

h1 {
    text-align: center;
    margin-bottom: 40px;
}

.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    max-width: 1200px;
    margin: auto;
}

.card {
    background: #ffffff;
    border-radius: 10px;
    padding: 25px 20px;
    text-align: center;
    text-decoration: none;
    color: #000;
    box-shadow: 0 3px 10px rgba(0,0,0,.1);
    transition: .2s;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 18px rgba(0,0,0,.2);
}

.card h2 {
    font-size: 1.1rem;
    margin-bottom: 15px;
    color: #555;
}

.card p {
    font-size: 1.9rem;
    font-weight: bold;
    color: #111;
}
</style>
</head>

<body>

<h1>Dashboard – Centro de Distribuição</h1>

<div class="cards">

    <a href="../relatorios/relatorio_produtos.php" class="card">
        <h2>Total de Produtos</h2>
        <p><?= $totalProdutos ?></p>
    </a>

    <a href="../relatorios/relatorio_estoque_baixo.php" class="card">
        <h2>Estoque Baixo</h2>
        <p><?= $estoqueBaixo ?></p>
    </a>

    <a href="../relatorios/relatorio_proximos_validade.php" class="card">
        <h2>Próx. da Validade</h2>
        <p><?= $proximosValidade ?></p>
    </a>

    <a href="../relatorios/relatorio_expedicoes.php" class="card">
        <h2>Expedições</h2>
        <p><?= $totalExpedicao ?></p>
    </a>

    <a href="../relatorios/relatorio_armazenagem.php" class="card">
        <h2>Posições em Estoque</h2>
        <p><?= $totalArmazenagem ?></p>
    </a>

    <a href="../relatorios/relatorio_valor_estoque.php" class="card">
        <h2>Valor do Estoque</h2>
        <p>R$ <?= number_format($totalValorEstoque, 2, ',', '.') ?></p>
    </a>

    <a href="../relatorios/relatorio_valor_expedicoes.php" class="card">
        <h2>Valor Expedido</h2>
        <p>R$ <?= number_format($totalValorExpedicao, 2, ',', '.') ?></p>
    </a>

</div>

</body>
</html>
