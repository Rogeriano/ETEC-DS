<?php
// Para controlar a sub-aba interna
$subpage = $_GET['sub'] ?? 'fornecedor';
?>

<h1>Cadastro</h1>

<!-- Sub-abas internas -->
<div class="sub-abas">
    <a href="?page=cadastro&sub=fornecedor" <?= $subpage=='fornecedor'?'class="ativa"':'' ?>>Fornecedor</a> |
    <a href="?page=cadastro&sub=categorias" <?= $subpage=='categorias'?'class="ativa"':'' ?>>Categoria</a> |
    <a href="?page=cadastro&sub=produtos" <?= $subpage=='produtos'?'class="ativa"':'' ?>>Produto</a>
</div>
<hr>

<!-- Conteúdo da sub-aba -->
<div class="conteudo-sub-aba">
    <?php
    switch($subpage){
        case 'fornecedor':
            include 'fornecedor.php';
            break;
        case 'categorias':
            include 'categorias.php';
            break;
        case 'produtos':
            include 'produtos.php';
            break;
        default:
            echo "<p>Aba não encontrada.</p>";
    }
    ?>
</div>
