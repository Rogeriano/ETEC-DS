<?php
require 'protege.php';
require 'conexao.php';

$page = $_GET['page'] ?? 'home';

$whitelist = [
    'home',
    'produtos',
    'cadastro',
    'recebimento',
    'armazenagem',
    'expedicao',
    'relatorios',
    'movimentacoes'
];

if (!in_array($page, $whitelist)) {
    $page = '404';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Admin</title>

    <!-- CSS GLOBAL -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS ESPECÍFICO POR PÁGINA -->
     

    <?php if($page == 'dashboard'): ?>
        <link rel="stylesheet" href="../css/style.css">
    <?php elseif($page == 'cadastro'): ?>
        <link rel="stylesheet" href="../css/cadastro.css">
        <link rel="stylesheet" href="../css/produtos_cadastrar.css">
    <?php elseif($page == 'expedicao'): ?>
        <link rel="stylesheet" href="../css/expedicao.css">
    <?php elseif($page == 'relatorios'): ?>
        <link rel="stylesheet" href="../css/relatorios.css">
    <?php elseif($page == 'armazenagem'): ?>
        <link rel="stylesheet" href="../css/armazenagem.css">
    <?php elseif($page == 'recebimento'): ?>
        <link rel="stylesheet" href="../css/recebimento.css">
    <?php endif; ?>
</head>

<body>

<nav class="navbar">
    <button id="btnMenu">☰</button>
    <h2>Painel Admin</h2>
    <a href="logout.php" class="logout-btn">Sair</a>
</nav>

<div class="layout">

    <aside id="sidebar" class="sidebar">
        <a href="dashboard.php?page=home">Home</a>
        <a href="dashboard.php?page=cadastro">Cadastro</a>
        <a href="dashboard.php?page=recebimento">Recebimento</a>
        <a href="dashboard.php?page=armazenagem">Armazenagem</a>
        <a href="dashboard.php?page=expedicao">Expedição</a>
        <a href="dashboard.php?page=relatorios">Relatórios</a>
    </aside>

    <main class="content">
        <?php 
        if ($page === '404') {
            echo "<h1>404 - Página não encontrada</h1>";
        } else {
            include "../php/$page.php";
        }
        ?>
    </main>

</div>

<script src="../js/script.js"></script>
</body>
</html>
