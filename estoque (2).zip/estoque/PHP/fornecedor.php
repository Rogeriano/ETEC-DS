<?php
require 'protege.php';
require 'conexao.php';

$mensagem = '';
$erro = '';
$edit = false;

// =====================
// Deletar fornecedor
// =====================
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM fornecedores WHERE id = :id");
    $stmt->execute(['id' => $id]);
    header("Location: dashboard.php?page=cadastro&sub=fornecedor");
    exit;
}

// =====================
// Editar fornecedor
// =====================
if (isset($_GET['edit'])) {
    $edit = true;
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM fornecedores WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $fornecedor = $stmt->fetch();
    if (!$fornecedor) die("Fornecedor não encontrado!");
}

// =====================
// Cadastro ou atualização
// =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $cnpj = $_POST['cnpj'] ?? '';
    $telefone = $_POST['telefone'] ?? '';
    $email = $_POST['email'] ?? '';
    $endereco = $_POST['endereco'] ?? '';

    if ($nome == '') {
        $erro = "Preencha o nome do fornecedor.";
    } else {
        // Verificar duplicidade
        $stmtVerifica = $pdo->prepare("SELECT id FROM fornecedores WHERE nome = :nome");
        $stmtVerifica->execute(['nome' => $nome]);
        $existe = $stmtVerifica->fetch();

        if ($existe && (!$edit || $existe['id'] != $id)) {
            $erro = "O fornecedor '$nome' já existe!";
        } else {
            if ($edit) {
                $stmt = $pdo->prepare("UPDATE fornecedores 
                    SET nome=:nome, cnpj=:cnpj, telefone=:telefone, email=:email, endereco=:endereco 
                    WHERE id=:id");
                $stmt->execute([
                    'nome' => $nome,
                    'cnpj' => $cnpj,
                    'telefone' => $telefone,
                    'email' => $email,
                    'endereco' => $endereco,
                    'id' => $id
                ]);
                $mensagem = "Fornecedor atualizado com sucesso!";
            } else {
                $stmt = $pdo->prepare("INSERT INTO fornecedores (nome, cnpj, telefone, email, endereco) 
                    VALUES (:nome, :cnpj, :telefone, :email, :endereco)");
                $stmt->execute([
                    'nome' => $nome,
                    'cnpj' => $cnpj,
                    'telefone' => $telefone,
                    'email' => $email,
                    'endereco' => $endereco
                ]);
                $mensagem = "Fornecedor cadastrado com sucesso!";
            }
            header("Location: dashboard.php?page=cadastro&sub=fornecedor");
            exit;
        }
    }
}

// =====================
// Buscar fornecedores cadastrados
// =====================
$stmt = $pdo->query("SELECT * FROM fornecedores ORDER BY nome ASC");
$fornecedores = $stmt->fetchAll();
?>

<h1>Cadastro de Fornecedores</h1>

<?php if ($erro) echo "<p style='color:red;'>$erro</p>"; ?>
<?php if ($mensagem) echo "<p style='color:green;'>$mensagem</p>"; ?>

<!-- Formulário de cadastro/edição -->
<form method="post" style="margin-bottom:20px;">
    <input type="text" name="nome" placeholder="Nome" value="<?= $edit ? htmlspecialchars($fornecedor['nome']) : '' ?>" required><br><br>
    <input type="text" name="cnpj" placeholder="CNPJ" value="<?= $edit ? htmlspecialchars($fornecedor['cnpj']) : '' ?>"><br><br>
    <input type="text" name="telefone" placeholder="Telefone" value="<?= $edit ? htmlspecialchars($fornecedor['telefone']) : '' ?>"><br><br>
    <input type="email" name="email" placeholder="Email" value="<?= $edit ? htmlspecialchars($fornecedor['email']) : '' ?>"><br><br>
    <input type="text" name="endereco" placeholder="Endereço" value="<?= $edit ? htmlspecialchars($fornecedor['endereco']) : '' ?>"><br><br>
    <button type="submit"><?= $edit ? 'Salvar' : 'Cadastrar' ?></button>
    <?php if ($edit): ?>
        <a href="dashboard.php?page=cadastro&sub=fornecedor">Cancelar</a>
    <?php endif; ?>
</form>

<!-- Lista de fornecedores -->
<h2>Fornecedores Cadastrados</h2>
<?php if (count($fornecedores) > 0): ?>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CNPJ</th>
        <th>Telefone</th>
        <th>Email</th>
        <th>Endereço</th>
        <th>Ações</th>
    </tr>
    <?php foreach ($fornecedores as $f): ?>
    <tr>
        <td><?= $f['id'] ?></td>
        <td><?= htmlspecialchars($f['nome']) ?></td>
        <td><?= htmlspecialchars($f['cnpj']) ?></td>
        <td><?= htmlspecialchars($f['telefone']) ?></td>
        <td><?= htmlspecialchars($f['email']) ?></td>
        <td><?= htmlspecialchars($f['endereco']) ?></td>
        <td>
            <a href="dashboard.php?page=cadastro&sub=fornecedor&edit=<?= $f['id'] ?>">Editar</a> |
            <a href="dashboard.php?page=cadastro&sub=fornecedor&delete=<?= $f['id'] ?>" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p>Nenhum fornecedor cadastrado ainda.</p>
<?php endif; ?>
